#!/data/data/com.termux/files/usr/bin/bash
# Script de inicio rápido
cd "$(dirname "$0")/.."
python jarvis.py
