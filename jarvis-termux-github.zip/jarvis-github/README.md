# 🤖 Jarvis Termux - Asistente de Voz para Android

Asistente de voz ligero optimizado para teléfonos de gama baja (4 GB RAM), especialmente el **Infinix HOT 50i**.

Funciona 100% en **Termux** sin necesidad de root ni Android Studio.

---

## ✨ Características

- 🎤 Escucha comandos de voz (`termux-speech-to-text`)
- 🗣️ Habla respuestas (`termux-tts-speak`)
- 📱 Abre aplicaciones por voz (WhatsApp, YouTube, Cámara, Instagram, etc.)
- 🔋 Consulta el estado de la batería
- 🕐 Dice la hora actual
- ⚙️ Fácil de personalizar (agregar más apps)
- 🪶 Extremadamente ligero (ideal para 4 GB de RAM)

---

## 📦 Requisitos

1. **Termux** (descargar **solo** desde [F-Droid](https://f-droid.org/packages/com.termux/))
2. **Termux:API** (también desde F-Droid)
3. Permisos de **micrófono** y **almacenamiento** otorgados a ambas apps

> ⚠️ **Importante**: No uses las versiones de Google Play Store (están desactualizadas y limitadas).

---

## 🚀 Instalación

### Opción 1: Desde este repositorio (recomendado)

```bash
# En Termux
pkg update -y && pkg install -y git
git clone https://github.com/TU-USUARIO/jarvis-termux.git
cd jarvis-termux
bash install.sh
```

### Opción 2: Manual

1. Descarga el ZIP de este repositorio
2. Descomprime la carpeta
3. Abre Termux y navega hasta la carpeta:
   ```bash
   cd /sdcard/Download/jarvis-termux
   bash install.sh
   ```

---

## 🎮 Uso

Una vez instalado, simplemente escribe:

```bash
jarvis
```

o

```bash
python jarvis.py
```

### Comandos de ejemplo

| Comando                  | Acción                     |
|--------------------------|----------------------------|
| `hola jarvis`            | Saludo                     |
| `abrir whatsapp`         | Abre WhatsApp              |
| `abrir youtube`          | Abre YouTube               |
| `abrir cámara`           | Abre la cámara             |
| `qué hora es`            | Dice la hora               |
| `batería`                | Estado de la batería       |
| `salir` / `apagar`       | Cierra Jarvis              |

---

## ⚙️ Personalizar aplicaciones

Edita el archivo `config/apps.json` y agrega nuevas apps:

```json
{
  "whatsapp": "com.whatsapp",
  "miapp": "com.paquete.de.la.app"
}
```

Para encontrar el package name de cualquier app:

```bash
pm list packages | grep -i nombre
```

---

## 📁 Estructura del proyecto

```
jarvis-termux/
├── jarvis.py              # Código principal del asistente
├── install.sh             # Script de instalación automática
├── config/
│   └── apps.json          # Lista de aplicaciones
├── scripts/
│   └── start.sh
├── LICENSE
└── README.md
```

---

## ⚠️ Limitaciones

- No puede leer mensajes de WhatsApp automáticamente (eso requiere Accessibility Service de una app nativa en Kotlin/Java).
- El reconocimiento de voz depende de `termux-speech-to-text` (usa el motor de Google).
- Funciona mejor en entornos silenciosos.

---

## 📄 Licencia

MIT License - Puedes usarlo, modificarlo y distribuirlo libremente.

---

## 🤝 Contribuciones

¡Las pull requests son bienvenidas! Si agregas más comandos o mejoras, haz un fork y envía un PR.
