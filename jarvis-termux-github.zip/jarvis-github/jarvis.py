#!/data/data/com.termux/files/usr/bin/python
# -*- coding: utf-8 -*-
"""
JARVIS Termux - Asistente de voz ligero para Android
Optimizado para dispositivos de 4 GB de RAM (Infinix HOT 50i y similares)
"""

import subprocess
import json
import os
import time
import re
from datetime import datetime

# ==================== CONFIGURACIÓN ====================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APPS_FILE = os.path.join(BASE_DIR, "config", "apps.json")

# Cargar lista de aplicaciones
try:
    with open(APPS_FILE, "r", encoding="utf-8") as f:
        APPS = json.load(f)
except Exception:
    APPS = {}

# ==================== FUNCIONES DE VOZ ====================

def speak(text: str):
    """Hablar usando termux-tts-speak"""
    print(f"JARVIS » {text}")
    try:
        subprocess.run(
            ["termux-tts-speak", text],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=30
        )
    except Exception as e:
        print(f"[Error TTS] {e}")


def listen(timeout: int = 10) -> str:
    """Escuchar con termux-speech-to-text"""
    print("🎤 Escuchando...")
    try:
        result = subprocess.run(
            ["termux-speech-to-text"],
            capture_output=True,
            text=True,
            timeout=timeout + 5
        )
        text = result.stdout.strip().lower()
        if text:
            print(f"Tú » {text}")
            return text
        return ""
    except subprocess.TimeoutExpired:
        print("⏱ Tiempo de escucha agotado")
        return ""
    except Exception as e:
        print(f"[Error STT] {e}")
        return ""


# ==================== FUNCIONES DEL SISTEMA ====================

def open_app(package: str) -> bool:
    """Abrir una aplicación por su package name"""
    try:
        # Método más compatible
        subprocess.run(
            [
                "am", "start",
                "-a", "android.intent.action.MAIN",
                "-c", "android.intent.category.LAUNCHER",
                package
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5
        )
        return True
    except Exception:
        try:
            subprocess.run(
                ["termux-open", f"package:{package}"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5
            )
            return True
        except Exception:
            return False


def get_battery() -> str:
    """Obtener estado de la batería"""
    try:
        out = subprocess.check_output(
            ["termux-battery-status"],
            text=True,
            timeout=5
        )
        data = json.loads(out)
        percent = data.get("percentage", "?")
        status = data.get("status", "desconocido")
        return f"La batería está al {percent} por ciento. Estado: {status.lower()}"
    except Exception:
        return "No pude obtener el estado de la batería"


def get_time() -> str:
    """Obtener la hora actual"""
    now = datetime.now()
    # Traducción simple de meses
    meses = {
        1: "enero", 2: "febrero", 3: "marzo", 4: "abril",
        5: "mayo", 6: "junio", 7: "julio", 8: "agosto",
        9: "septiembre", 10: "octubre", 11: "noviembre", 12: "diciembre"
    }
    mes = meses.get(now.month, str(now.month))
    return f"Son las {now.strftime('%H:%M')} del {now.day} de {mes}"


# ==================== PROCESADOR DE COMANDOS ====================

def process_command(text: str) -> bool:
    """
    Procesa el comando de voz.
    Retorna False si se debe salir del programa.
    """
    text = text.lower().strip()

    # ----- Salir -----
    if any(w in text for w in ["salir", "apagar", "adios", "adiós", "bye", "cerrar jarvis", "hasta luego"]):
        speak("Hasta luego. Apagando Jarvis.")
        return False

    # ----- Saludos -----
    if any(w in text for w in ["hola", "hey jarvis", "buenos días", "buenas tardes", "buenas noches", "qué tal"]):
        speak("Hola. ¿En qué te puedo ayudar?")
        return True

    # ----- Hora -----
    if any(w in text for w in ["hora", "qué hora", "que hora", "time", "hora actual"]):
        speak(get_time())
        return True

    # ----- Batería -----
    if any(w in text for w in ["batería", "bateria", "battery", "carga", "nivel de batería"]):
        speak(get_battery())
        return True

    # ----- Abrir aplicaciones -----
    for name, package in APPS.items():
        # Detecta "abrir whatsapp", "abre youtube", "whatsapp", etc.
        if name in text:
            speak(f"Abriendo {name}")
            success = open_app(package)
            if not success:
                speak(f"No pude abrir {name}. Verifica que esté instalada.")
            return True

    # Comando genérico "abrir X"
    match = re.search(r"(abrir|abre|open|lanza|ejecuta)\s+(.+)", text)
    if match:
        app_name = match.group(2).strip()
        if app_name in APPS:
            speak(f"Abriendo {app_name}")
            open_app(APPS[app_name])
        else:
            speak(f"No tengo registrada la aplicación {app_name}. Puedes agregarla en config/apps.json")
        return True

    # ----- Respuesta por defecto -----
    speak("No entendí el comando. Prueba con: abrir whatsapp, qué hora es, o batería.")
    return True


# ==================== BUCLE PRINCIPAL ====================

def main():
    speak("Jarvis activado. Di un comando.")

    while True:
        try:
            command = listen()
            if not command:
                continue

            should_continue = process_command(command)
            if not should_continue:
                break

            time.sleep(0.4)

        except KeyboardInterrupt:
            speak("Hasta luego.")
            break
        except Exception as e:
            print(f"[Error] {e}")
            time.sleep(1)


if __name__ == "__main__":
    main()
