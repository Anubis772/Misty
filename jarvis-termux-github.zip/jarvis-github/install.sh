#!/data/data/com.termux/files/usr/bin/bash

set -e

echo ""
echo "=========================================="
echo "   🤖  Instalando JARVIS Termux"
echo "   Optimizado para 4 GB de RAM"
echo "=========================================="
echo ""

# Colores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}[1/4] Actualizando repositorios...${NC}"
pkg update -y > /dev/null 2>&1
pkg upgrade -y > /dev/null 2>&1

echo -e "${YELLOW}[2/4] Instalando dependencias...${NC}"
pkg install -y python termux-api espeak > /dev/null 2>&1

echo -e "${YELLOW}[3/4] Instalando librerías Python...${NC}"
pip install --upgrade pip > /dev/null 2>&1
pip install requests > /dev/null 2>&1

echo -e "${YELLOW}[4/4] Configurando comandos...${NC}"
chmod +x jarvis.py
chmod +x scripts/*.sh 2>/dev/null || true

# Crear el comando global "jarvis"
mkdir -p "$PREFIX/bin"
cp jarvis.py "$PREFIX/bin/jarvis"
chmod +x "$PREFIX/bin/jarvis"

echo ""
echo -e "${GREEN}✅ Instalación completada con éxito${NC}"
echo ""
echo "Para iniciar Jarvis escribe:"
echo ""
echo "    jarvis"
echo ""
echo "Asegúrate de haber otorgado permisos de micrófono"
echo "a Termux y Termux:API en Ajustes del sistema."
echo ""
echo "=========================================="
